const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const session = require('express-session');
const bcrypt = require('bcrypt');




const app = express();
app.use(express.static('public'));
app.use('/images', express.static((__dirname, 'public/images')));

// Configuração do body-parser
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Configuração do MySQL
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Gra@170507',
    database: 'planetas'
});

connection.connect((err) => {
    if (err) throw err;
    console.log('Conectado ao MySQL!');
});

// Configuração do middleware de sessão
app.use(session({
    secret: '12345',
    resave: false,
    saveUninitialized: false
}));

// Rota para a página de login
app.get('/login', (req, res) => {
    res.render('login.ejs');
});

// Rota para o processo de login
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    // Buscar o hash da senha do usuário no banco de dados
    connection.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) throw err;
        if (results.length > 0) {
            const user = results[0];
            // Comparar a senha fornecida pelo usuário com o hash armazenado no banco de dados
            bcrypt.compare(password, user.password, (err, result) => {
                if (err) throw err;
                if (result) {
                    // Definir a variável de sessão 'authenticated' como true após um login bem-sucedido
                    req.session.authenticated = true;
                    res.redirect('/index'); // Redireciona para a página index após o login bem-sucedido
                } else {
                    res.send('Usuário ou senha incorretos.');
                }
            });
        } else {
            res.send('Usuário ou senha incorretos.');
        }
    });
});

// Rota para a página de cadastro
app.get('/cadastro', (req, res) => {
    res.render('cadastro.ejs');
});

// Rota para o processo de cadastro
app.post('/cadastro', (req, res) => {
    const { username, password } = req.body;
    // Hash da senha usando bcrypt
    bcrypt.hash(password, 10, (err, hash) => {
        if (err) throw err;
        // Inserindo o usuário no banco de dados com a senha criptografada
        connection.query('INSERT INTO users (username, password) VALUES (?, ?)', [username, hash], (err, results) => {
            if (err) throw err;
            // Após o cadastro bem-sucedido, definimos a variável de sessão como true e redirecionamos para a página principal
            req.session.authenticated = true;
            res.redirect('/index');
        });
    });
});

// Rota para a página principal (index.ejs)
app.get('/index', (req, res) => {
    // Verificar se o usuário está autenticado antes de acessar a página principal
    if (req.session.authenticated) {
        res.render('index.ejs'); // Renderizar a página principal se o usuário estiver autenticado
    } else {
        res.redirect('/login'); // Redirecionar para a página de login se o usuário não estiver autenticado
    }
});

app.listen(3000, () => {
    console.log('Servidor rodando em http://localhost:3000/login');
});
